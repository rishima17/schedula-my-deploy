// src/doctor/doctor.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DoctorService } from './doctor.service';
import { DoctorController } from './doctor.controller';
import { Doctor } from '../entities/Doctor';
import { User } from '../entities/User';
import { Availability } from '../entities/Availability';
import { AvailabilityService } from '../availability/availability.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Doctor, User, Availability]), // ✅ Add User here
  ],
  controllers: [DoctorController],
  providers: [DoctorService, AvailabilityService],
  exports: [DoctorService],
})
export class DoctorModule {}
