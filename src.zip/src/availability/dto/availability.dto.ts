// src/availability/dto/availability.dto.ts
import { IsInt, IsString, IsDateString, Min, Max } from 'class-validator';

export class CreateAvailabilityDto {
  @IsInt()
  @Min(0)
  @Max(6)
  dayOfWeek: number; // 0 = Sunday, 6 = Saturday

  @IsDateString()
  date: string; // 'YYYY-MM-DD' format

  @IsString()
  startTime: string; // 'HH:MM:SS'

  @IsString()
  endTime: string; // 'HH:MM:SS'
}
