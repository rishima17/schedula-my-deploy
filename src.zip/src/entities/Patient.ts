import { Entity, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, JoinColumn } from 'typeorm';
import { User } from './User';
import { Appointment } from './Appointment';
import { OnboardingProgress } from './onboarding-progress.entity';

@Entity()
export class Patient {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  age: number;

  @Column({ default: false })
  isVerified: boolean;

  @OneToOne(() => User, (user) => user.patient, { onDelete: 'CASCADE' })
  @JoinColumn()
  user: User;

  @OneToMany(() => Appointment, (appointment) => appointment.patient)
  appointments: Appointment[];

  // ✅ Add inverse relation for onboarding progress
  @OneToMany(() => OnboardingProgress, (progress) => progress.patient)
  onboardingProgress: OnboardingProgress[];
}
