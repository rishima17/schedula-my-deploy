import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Availability } from '../entities/Availability';

@Injectable()
export class AvailabilityService {
  constructor(
    @InjectRepository(Availability)
    private availabilityRepo: Repository<Availability>,
  ) {}

  // Create a new availability
  create(data: Partial<Availability>) {
    const availability = this.availabilityRepo.create(data);
    return this.availabilityRepo.save(availability);
  }

  // List availability for a doctor
  findByDoctor(doctorId: number) {
    return this.availabilityRepo.find({
      where: { doctor: { id: doctorId } },
      relations: ['doctor'],
    });
  }

  // Get available slots for booking
  async getAvailableSlots(doctorId: number, date: string) {
    const slots = await this.availabilityRepo.find({
      where: { doctor: { id: doctorId }, day: date, status: 'free' },
      order: { startTime: 'ASC' },
      relations: ['doctor'],
    });

    return slots.map(slot => ({
      time: `${slot.day}T${slot.startTime}`,
      available: slot.capacity,
    }));
  }

  // Expand availability
  async expandAvailability(dto: {
    doctorId: number;
    date: string;
    newEndTime: string;
    waveDuration: number;
    waveSize: number;
  }) {
    const { doctorId, date, newEndTime, waveDuration, waveSize } = dto;

    // Get all existing slots for the day
    const existing = await this.availabilityRepo.find({
      where: { doctor: { id: doctorId }, day: date },
      order: { startTime: 'ASC' },
    });

    if (!existing.length) throw new Error('No existing slots to expand');

    // Find the last slot
    const lastSlot = existing[existing.length - 1];

    // If new end time extends beyond last slot, expand it
    const slotsToAdd: Availability[] = [];
    let currentTime = lastSlot.endTime;

    const addMinutes = (time: string, mins: number) => {
      const [h, m] = time.split(':').map(Number);
      const dt = new Date();
      dt.setHours(h, m + mins);
      const hh = dt.getHours().toString().padStart(2, '0');
      const mm = dt.getMinutes().toString().padStart(2, '0');
      return `${hh}:${mm}`;
    };

    // Expand by modifying last slot if waveDuration or waveSize increased
    lastSlot.endTime = newEndTime;
    lastSlot.capacity = waveSize;
    lastSlot.waveDuration = waveDuration;
    await this.availabilityRepo.save(lastSlot);

    // Generate new slots beyond currentTime if necessary
    while (currentTime < newEndTime) {
      const waveEnd = addMinutes(currentTime, waveDuration);

      // Avoid creating duplicate
      if (!existing.find(e => e.startTime === currentTime)) {
        slotsToAdd.push(
          this.availabilityRepo.create({
            doctor: { id: doctorId },
            day: date,
            startTime: currentTime,
            endTime: waveEnd,
            waveDuration,
            capacity: waveSize,
            status: 'free',
          }),
        );
      }

      currentTime = waveEnd;
    }

    return this.availabilityRepo.save(slotsToAdd);
  }
}
