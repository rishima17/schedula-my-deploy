// availability.controller.ts
import { Controller, Get, Post, Param, Body, ParseIntPipe } from '@nestjs/common';
import { AvailabilityService } from './availability.service';
import { CreateAvailabilityDto } from './dto/availability.dto';

@Controller('api/v1/doctors/:doctorId/availability')
export class AvailabilityController {
  constructor(private readonly availabilityService: AvailabilityService) {}

  // Create availability for a doctor
  @Post()
  async createAvailability(
    @Param('doctorId', ParseIntPipe) doctorId: number,
    @Body() dto: CreateAvailabilityDto,
  ) {
    return await this.availabilityService.createAvailability(doctorId, dto);
  }

  // List all availability for a doctor
  @Get()
  async listAvailability(@Param('doctorId', ParseIntPipe) doctorId: number) {
    return await this.availabilityService.listAvailability(doctorId);
  }

  // Optional: get availability on a specific date
  @Get(':date')
  async getAvailabilityByDate(
    @Param('doctorId', ParseIntPipe) doctorId: number,
    @Param('date') date: string,
  ) {
    return await this.availabilityService.getAvailabilityByDate(doctorId, date);
  }
}
