import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Doctor } from './Doctor';
import { Patient } from './Patient';
import { Availability } from './Availability';

@Entity()
export class Appointment {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Doctor, (doctor) => doctor.appointments, { onDelete: 'CASCADE' })
  doctor: Doctor;

  @ManyToOne(() => Patient, (patient) => patient.appointments, { onDelete: 'CASCADE' })
  patient: Patient;

  @ManyToOne(() => Availability, (availability) => availability.appointments, { onDelete: 'CASCADE' })
  availability: Availability;

 @Column({ type: 'timestamp' })
slotTime: Date;


  @Column({ type: 'enum', enum: ['booked', 'completed', 'cancelled'], default: 'booked' })
  status: string;
  @Column({ type: 'timestamp' })
slot: Date;

}
