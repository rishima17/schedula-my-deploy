import { Entity, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, JoinColumn } from 'typeorm';
import { User } from './User';
import { Availability } from './Availability';
import { Appointment } from './Appointment';

@Entity()
export class Doctor {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  specialization: string;

  @Column({ type: 'int', default: 15 })
  slotDuration: number;

  @Column({ type: 'varchar', default: 'wave' })
  scheduleType: string;

  @Column({ type: 'varchar', default: '09:00:00' })
  consultingStart: string;

  @Column({ type: 'varchar', default: '16:00:00' })
  consultingEnd: string;

  @Column({ type: 'int', default: 5 })
  capacityPerSlot: number;

  @Column({ type: 'int', default: 100 })
  dailyCapacity: number;

  @Column({ type: 'int', default: 0 }) // Add default experience
  experience: number;

  @OneToOne(() => User, { cascade: true }) // cascade allows nested object creation
  @JoinColumn()
  user: User;

  @OneToMany(() => Availability, (availability) => availability.doctor)
  availabilities: Availability[];

  @OneToMany(() => Appointment, (appointment) => appointment.doctor)
  appointments: Appointment[];
}
