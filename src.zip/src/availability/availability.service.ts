import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Availability } from '../entities/Availability';
import { Doctor } from '../entities/Doctor';
import { CreateAvailabilityDto } from './dto/availability.dto';

@Injectable()
export class AvailabilityService {
  constructor(
    @InjectRepository(Availability)
    private readonly availabilityRepository: Repository<Availability>,

    @InjectRepository(Doctor)
    private readonly doctorRepository: Repository<Doctor>,
  ) {}

  // Create availability
  async createAvailability(doctorId: number, dto: CreateAvailabilityDto) {
    const doctor = await this.doctorRepository.findOne({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Doctor not found');

    const availability = this.availabilityRepository.create({
      doctor, // use relation instead of doctorId
      dayOfWeek: dto.dayOfWeek,
      date: dto.date,
      startTime: dto.startTime,
      endTime: dto.endTime,
    });

    return this.availabilityRepository.save(availability);
  }

  // List availabilities for a doctor
  async listAvailability(doctorId: number) {
    const doctor = await this.doctorRepository.findOne({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Doctor not found');

    return this.availabilityRepository.find({
      where: { doctor }, // use relation instead of doctorId
      order: { date: 'ASC', startTime: 'ASC' },
    });
  }

  // Example: find by doctor and date
  async getAvailabilityByDate(doctorId: number, date: string) {
    const doctor = await this.doctorRepository.findOne({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Doctor not found');

    return this.availabilityRepository.find({
      where: { doctor, date }, // relation + date
    });
  }
}
