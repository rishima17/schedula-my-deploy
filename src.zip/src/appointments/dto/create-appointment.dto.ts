import { IsNumber, IsISO8601 } from 'class-validator';

export class CreateAppointmentDto {
  @IsNumber()
  patientId: number;

  @IsNumber()
  doctorId: number;

  @IsNumber()
  availabilityId: number;

  @IsISO8601()
  slot: string; // specific ISO time inside availability
}
