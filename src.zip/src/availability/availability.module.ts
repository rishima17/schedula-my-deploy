// src/availability/availability.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AvailabilityService } from './availability.service';
import { AvailabilityController } from './availability.controller';
import { Availability } from '../entities/Availability';
import { Doctor } from '../entities/Doctor';

@Module({
  imports: [
    TypeOrmModule.forFeature([Availability, Doctor]), // ✅ Add Doctor here
  ],
  controllers: [AvailabilityController],
  providers: [AvailabilityService],
  exports: [AvailabilityService],
})
export class AvailabilityModule {}
