import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-google-oauth20';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../entities/User';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) {
    super({
      clientID: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      callbackURL: process.env.GOOGLE_CALLBACK_URL!,
      passReqToCallback: true,
      scope: ['email', 'profile'],
    });
  }

  async validate(
    req: any,
    accessToken: string,
    refreshToken: string,
    profile: any,
    done: Function,
  ) {
    try {
      // Extract role from state if passed
      const state = req.query.state ? JSON.parse(req.query.state) : {};
      const role = state.role || 'patient';

      const email = profile.emails?.[0]?.value;
      const name = profile.displayName;

      if (!email) {
        return done(new Error('Google profile does not have email'), null);
      }

      // 🔍 Check if user exists
      let user = await this.userRepo.findOne({ where: { email } });

      if (!user) {
        // 🆕 Create new user with a random password (TypeScript-safe)
        user = this.userRepo.create({
          email,
          name,
          role,
          provider: 'google',
          password: Math.random().toString(36).slice(-8), // temp password
        });

        await this.userRepo.save(user);
      }

      return done(null, user);
    } catch (err) {
      return done(err, false);
    }
  }
}
