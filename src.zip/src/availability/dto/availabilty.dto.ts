export class ExpandAvailabilityDto {
  doctorId: number;
  date: string;        // 'YYYY-MM-DD'
  newEndTime: string;  // 'HH:MM'
  waveDuration: number;
  waveSize: number;
}
