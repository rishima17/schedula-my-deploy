// src/doctor/doctor.service.ts

import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Doctor } from '../entities/Doctor';
import { User } from '../entities/User';

@Injectable()
export class DoctorService {
  constructor(
    @InjectRepository(Doctor)
    private readonly doctorRepository: Repository<Doctor>,

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  // ---------------- Create or Update doctor linked to a user ----------------
  async createOrUpdateDoctor(
    userId: number,
    specialization: string,
    experience = 0, // optional parameter with default value
  ) {
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    // 🔹 Check if a doctor profile already exists for this user
    let doctor = await this.doctorRepository.findOne({
      where: { user: { id: userId } },
      relations: ['user'],
    });

    if (doctor) {
      // 🔹 Update existing doctor profile
      doctor.specialization = specialization;
      doctor.experience = experience;
      doctor.slotDuration = 15;
      doctor.scheduleType = 'wave';
      doctor.consultingStart = '09:00:00';
      doctor.consultingEnd = '16:00:00';
      doctor.capacityPerSlot = 5;
      doctor.dailyCapacity = 100;

      return this.doctorRepository.save(doctor);
    }

    // 🔹 Create a new doctor profile if not found
    doctor = this.doctorRepository.create({
      user,
      specialization,
      experience,
      slotDuration: 15,
      scheduleType: 'wave',
      consultingStart: '09:00:00',
      consultingEnd: '16:00:00',
      capacityPerSlot: 5,
      dailyCapacity: 100,
    });

    return this.doctorRepository.save(doctor);
  }

  // ---------------- Get all doctors ----------------
  async getAllDoctors() {
    return this.doctorRepository.find({ relations: ['user'] });
  }

  // ---------------- Filter doctors by id or specialization ----------------
  async filterDoctors(query: { id?: number; specialization?: string }) {
    const qb = this.doctorRepository
      .createQueryBuilder('doctor')
      .leftJoinAndSelect('doctor.user', 'user');

    if (query.id) {
      qb.andWhere('doctor.id = :id', { id: query.id });
    }

    if (query.specialization) {
      qb.andWhere('doctor.specialization = :specialization', {
        specialization: query.specialization,
      });
    }

    const doctors = await qb.getMany();

    if (!doctors || doctors.length === 0) {
      throw new NotFoundException('No doctors found with given criteria');
    }

    return doctors;
  }
}
