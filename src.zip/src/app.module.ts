import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';

import { User } from './entities/User';
import { Patient } from './entities/Patient';
import { Doctor } from './entities/Doctor';
import { OnboardingProgress } from './entities/onboarding-progress.entity';
import { Appointment } from './entities/Appointment';

import { VerificationModule } from './verification/verification.module';
import { OnboardingModule } from './onboarding/onboarding.module';
import { AppointmentModule } from './appointments/appointment.module';
import { DoctorModule } from './doctor/doctor.module';
import { AuthModule } from './auth/auth.module';
import { AvailabilityModule } from './availability/availability.module';
import { Availability } from './entities/Availability';

@Module({
  imports: [
    // ✅ Loads .env globally
    ConfigModule.forRoot({ isGlobal: true }),

    // ✅ Database connection
    TypeOrmModule.forRoot({
      type: 'postgres',
      host:  'localhost',
      port: 5432,
      username: "postgres",
      password:'root1234',
      database:  'PearlThoughts',
      entities: [User, Patient, Doctor, OnboardingProgress, Appointment,Availability],
    synchronize: false,
migrations: ['dist/migrations/*.js'],

    }),

    // ✅ Feature modules
    AuthModule,
    VerificationModule,
    OnboardingModule,
    AppointmentModule,
    DoctorModule,
    AvailabilityModule,
  ],
})
export class AppModule {}
