import { Controller, Get, Param, Post, Body, Query, ParseIntPipe } from '@nestjs/common';
import { AppointmentService } from './appointment.service';
import { CreateAppointmentDto } from './dto/create-appointment.dto';

@Controller('api/v1/appointments')
export class AppointmentController {
  constructor(private readonly svc: AppointmentService) {}

  // List all doctors
  @Get('doctors')
  listDoctors() {
    return this.svc.listDoctors();
  }

  // Get available slots for a doctor on a given date
  @Get('doctors/:doctorId/available-slots')
  getSlots(
    @Param('doctorId', ParseIntPipe) doctorId: number,
    @Query('date') date: string,
  ) {
    return this.svc.getAvailableSlots(doctorId, date);
  }

  // Confirm an appointment
  @Post('confirm')
  confirm(@Body() dto: CreateAppointmentDto) {
    return this.svc.confirmAppointment(dto);
  }

  // Get full appointment details
  @Get(':id')
  getAppointment(@Param('id', ParseIntPipe) id: number) {
    return this.svc.getAppointmentDetails(id);
  }
}
