import { Injectable, NotFoundException, BadRequestException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Appointment } from '../entities/Appointment';
import { Patient } from '../entities/Patient';
import { Doctor } from '../entities/Doctor';
import { Availability } from '../entities/Availability';
import { CreateAppointmentDto } from './dto/create-appointment.dto';

@Injectable()
export class AppointmentService {
  constructor(
    @InjectRepository(Appointment)
    private readonly apptRepo: Repository<Appointment>,

    @InjectRepository(Patient)
    private readonly patientRepo: Repository<Patient>,

    @InjectRepository(Doctor)
    private readonly doctorRepo: Repository<Doctor>,

    @InjectRepository(Availability)
    private readonly availRepo: Repository<Availability>,
  ) {}

  /** List all doctors */
  async listDoctors() {
    return this.doctorRepo.find({ relations: ['user'] });
  }

  /** Get available slots for a doctor on a given date */
  async getAvailableSlots(doctorId: number, date: string) {
    const doctor = await this.doctorRepo.findOne({
      where: { id: doctorId },
      relations: ['availabilities', 'availabilities.appointments'],
    });
    if (!doctor) throw new NotFoundException('Doctor not found');

    const day = new Date(date);
    if (isNaN(day.getTime())) throw new BadRequestException('Invalid date');

    const dayOfWeek = day.getDay();

    const availabilities = doctor.availabilities.filter(
      (a) => a.dayOfWeek === dayOfWeek,
    );

    const slots: { time: string; available: boolean }[] = [];

    for (const avail of availabilities) {
      const [startHour, startMin] = avail.startTime.split(':').map(Number);
      const [endHour, endMin] = avail.endTime.split(':').map(Number);

      const start = new Date(day);
      start.setHours(startHour, startMin, 0, 0);

      const end = new Date(day);
      end.setHours(endHour, endMin, 0, 0);

      for (let t = new Date(start); t < end; t.setMinutes(t.getMinutes() + doctor.slotDuration)) {
        const booked = avail.appointments.find(
          (a) => a.slot.getTime() === t.getTime(),
        );
        slots.push({ time: t.toISOString(), available: !booked });
      }
    }

    return slots;
  }

  /** Confirm appointment */
  async confirmAppointment(dto: CreateAppointmentDto) {
    const { patientId, doctorId, availabilityId, slot } = dto;

    const patient = await this.patientRepo.findOne({ where: { id: patientId } });
    if (!patient) throw new NotFoundException('Patient not found');
    if (!patient.isVerified) throw new ConflictException('Patient must be verified');

    const doctor = await this.doctorRepo.findOne({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Doctor not found');

    const availability = await this.availRepo.findOne({
      where: { id: availabilityId },
      relations: ['appointments'],
    });
    if (!availability) throw new NotFoundException('Availability not found');

    const slotDate = new Date(slot);
    if (isNaN(slotDate.getTime())) throw new BadRequestException('Invalid slot');

    const existing = availability.appointments.find(
      (a) => a.slot.getTime() === slotDate.getTime(),
    );
    if (existing) throw new BadRequestException('Slot already booked');

    const appt = this.apptRepo.create({
      patient: { id: patientId },
      doctor: { id: doctorId },
      availability: { id: availabilityId },
      slot: slotDate,
      status: 'confirmed',
    });

    return this.apptRepo.save(appt);
  }

  /** Get appointment details */
  async getAppointmentDetails(id: number) {
    const appt = await this.apptRepo.findOne({
      where: { id },
      relations: ['patient', 'doctor', 'availability'],
    });
    if (!appt) throw new NotFoundException('Appointment not found');
    return appt;
  }
}
