import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Patient } from './Patient';

@Entity()
export class OnboardingProgress {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  stepId: number; // number representing the step order

  // ✅ Make JSON column nullable and give default empty object
  @Column('json', { nullable: true, default: {} })
  data: any;

  // ✅ Link to patient
  @ManyToOne(() => Patient, (patient) => patient.onboardingProgress, { onDelete: 'CASCADE' })
  patient: Patient;
}
