import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { Doctor } from './Doctor';
import { Appointment } from './Appointment';

@Entity()
export class Availability {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Doctor, (doctor) => doctor.availabilities, { onDelete: 'CASCADE' })
  doctor: Doctor; // This automatically creates a doctorId column in DB

  @Column({ type: 'int' })
  dayOfWeek: number;  // 0 = Sunday, 6 = Saturday

  @Column({ type: 'date' })
  date: string;

  @Column({ type: 'time' })
  startTime: string;

  @Column({ type: 'time' })
  endTime: string;

  @OneToMany(() => Appointment, (appointment) => appointment.availability)
  appointments: Appointment[];
}
