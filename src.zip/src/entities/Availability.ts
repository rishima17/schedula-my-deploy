import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Doctor } from './Doctor';

@Entity()
export class Availability {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'date' })
  day: string; // e.g., '2025-09-24'

  @Column({ type: 'time' })
  startTime: string; // e.g., '09:00'

  @Column({ type: 'time' })
  endTime: string; // e.g., '09:30'

  @Column({ default: 30 })
  waveDuration: number; // duration of the wave in minutes

  @Column({ default: 1 })
  capacity: number; // patients per wave

  @Column({ default: 'free' })
  status: string; // 'free' or 'booked'

  @ManyToOne(() => Doctor, (doctor) => doctor.availabilities, { onDelete: 'CASCADE' })
  doctor: Doctor;
}
