import {
  Controller,
  Get,
  Post,
  Param,
  Body,
  ParseIntPipe,
  Query,
} from '@nestjs/common';
import { DoctorService } from './doctor.service';
import { AvailabilityService } from '../availability/availability.service';
import { CreateAvailabilityDto } from '../availability/dto/availability.dto';

@Controller('api/v1/doctors')
export class DoctorController {
  constructor(
    private readonly doctorService: DoctorService,
    private readonly availabilityService: AvailabilityService,
  ) {}

  // ---------------- Doctor endpoints ----------------
  @Get()
  getAllDoctors() {
    return this.doctorService.getAllDoctors();
  }

  @Post('create')
  async createOrUpdateDoctor(
    @Body()
    body: { userId: number; specialization: string; experience?: number },
  ) {
    return this.doctorService.createOrUpdateDoctor(
      body.userId,
      body.specialization,
      body.experience,
    );
  }

  @Get('filter')
  getFilteredDoctors(@Query() query: any) {
    return this.doctorService.filterDoctors(query);
  }

  // ---------------- Availability endpoints ----------------
  @Post(':doctorId/availability')
  async createAvailability(
    @Param('doctorId', ParseIntPipe) doctorId: number,
    @Body() dto: CreateAvailabilityDto,
  ) {
    return await this.availabilityService.createAvailability(doctorId, dto);
  }

  @Get(':doctorId/availability')
  async listAvailability(@Param('doctorId', ParseIntPipe) doctorId: number) {
    return await this.availabilityService.listAvailability(doctorId);
  }
}
